#include <iostream>
#include "subdivider.h"

using namespace std;

int main() {
	Mesh in, out;
	vec3 p1 = { -1,1,1 };
	vec3 p2 = { -1,-1,-1 };
	vec3 p3 = { 1,-1,-1 };
	vec3 p4 = { 1,1,1 };

	vec3 q, w, e, r,z,x,c,v, n1, n2, n3, n4;
	vec3_sub(q, p2, p1);
	vec3_sub(w, p3, p2);
	vec3_sub(e, p4, p3);
	vec3_sub(r, p1, p4);

	vec3_counter(z, q);
	vec3_counter(x, w);
	vec3_counter(c, e);
	vec3_counter(v, r);

	vec3_mul_cross(n1, q, v);
	vec3_mul_cross(n2, z, w);
	vec3_mul_cross(n3, x, e);
	vec3_mul_cross(n4, c, r);

	*in.vertices[in.faces[0]->indices[0]]->position = *p1; 
	*in.vertices[in.faces[0]->indices[1]]->position = *p2;
	*in.vertices[in.faces[0]->indices[2]]->position = *p3;
	*in.vertices[in.faces[0]->indices[3]]->position = *p4;

	*in.vertices[in.faces[0]->indices[0]]->normal = *n1;
	*in.vertices[in.faces[0]->indices[1]]->normal = *n2;
	*in.vertices[in.faces[0]->indices[2]]->normal = *n3;
	*in.vertices[in.faces[0]->indices[3]]->normal = *n4;

	subdivider a;
	a.sd(out, in, 3);

	for (auto face : out.faces) {
		cout<< out.vertices[face->indices[0]]->position<<endl<< out.vertices[face->indices[1]]->position<<endl<< out.vertices[face->indices[2]]->position<<endl<< out.vertices[face->indices[3]]->position;    //out vertex
	}
	return 0;
}
